package py.com.unionsrl.labot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class ConfigActivity extends AppCompatActivity {
    private static final String TAG = "ConfigActivity";
    private RadioButton rbConfigHttp;
    private RadioButton rbConfigHttps;
    private EditText etConfigHost;
    private EditText etConfigPort;
    private Button btnConfigSave;
    private Database db = new Database(this);
    private Config config;
    private String protocol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        rbConfigHttp = (RadioButton) findViewById(R.id.rbConfigHttp);
        rbConfigHttps = (RadioButton) findViewById(R.id.rbConfigHttps);
        etConfigHost = (EditText) findViewById(R.id.etConfigHost);
        etConfigPort = (EditText) findViewById(R.id.etConfigPort);
        btnConfigSave = (Button) findViewById(R.id.btnConfigSave);

        config = new Config();
        config = db.selectConfig();
        if (config.getConfHost() != null) {

            protocol = config.getConfProtocol().toString();

            if (protocol.equalsIgnoreCase("http")) {
                rbConfigHttp.setChecked(true);
            } else {
                rbConfigHttps.setChecked(true);
            }
            etConfigHost.setText(config.getConfHost());
            etConfigPort.setText(config.getConfPort());
        }

        setupBtnConfigSave();
    }

    private void setupBtnConfigSave() {
        btnConfigSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(HomeActivity.this, TransactionActivity.class);
                //btnCerrarSesion.this.startActivity(intent);

                db.deleteConfig();

                if (rbConfigHttp.isChecked()) {
                    protocol = "http";
                } else {
                    protocol = "https";
                }

                config.setConfProtocol(protocol);
                config.setConfHost(etConfigHost.getText().toString());
                config.setConfPort(etConfigPort.getText().toString());

                db.insertConfig(config);
                iniciarLogin();
            }
        });
    }

    private void iniciarLogin() {

        Intent i = new Intent(this, LoginActivity.class);

        startActivity(i);

        finish();

    }
}