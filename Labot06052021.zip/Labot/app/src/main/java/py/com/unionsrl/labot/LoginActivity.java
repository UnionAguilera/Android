package py.com.unionsrl.labot;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {
  private static String TAG = "LoginActivity";
  private EditText etUsuario;
  private EditText etPassword;
  private Button btnIngresar;
  private Button btnConfigIni;
  private String usuario;
  private String password;
  private String url = "";
  private String resp;
  private Database db = new Database(this);
  private Config config;
  ProgressDialog mProgressDialog;
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    
    etUsuario = (EditText) findViewById(R.id.et_usuario);
    etPassword = (EditText) findViewById(R.id.et_password);
    btnIngresar = (Button) findViewById(R.id.btnIngresar);
    btnConfigIni = (Button) findViewById(R.id.btnConfigIni);
    
    setupBtnIngresar();
    setupBtnConfigIni();
    
    db = new Database(this.getApplicationContext());
    
  }
  
  private void setupBtnIngresar() {
    btnIngresar.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        login(v);
      }
    });
  }
  
  private void setupBtnConfigIni() {
    btnConfigIni.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        iniciarConfig();
      }
    });
  }
  
  public void login(View view) {
    try {
      usuario = etUsuario.getText().toString();
      password = etPassword.getText().toString();
      
      config = new Config();
      
      config = db.selectConfig();
      
      if (config.getConfHost() != null && config.getConfProtocol() != null && config.getConfPort() != null) {
        Parametros.confProtocol = config.getConfProtocol();
        Parametros.confHost = config.getConfHost();
        Parametros.confPort = config.getConfPort();
      }
      
      
      new LoginActivity.LoginCheck().execute();
      
    } catch (Exception e) {
      e.printStackTrace();
    }
    
  }
  
  public void iniciarConfig() {
    
    Intent i = new Intent(this, ConfigActivity.class);
    
    startActivity(i);
    
    finish();
    
  }
  
  // DownloadJSON AsyncTask
  private class LoginCheck extends AsyncTask < Void, Void, Void > {
    
    @Override
    protected void onPreExecute() {
      super.onPreExecute();
      // Create a progressdialog
      mProgressDialog = new ProgressDialog(LoginActivity.this);
      // Set progressdialog title
      mProgressDialog.setTitle("Espere un momento");
      // Set progressdialog message
      mProgressDialog.setMessage("Abriendo...");
      mProgressDialog.setIndeterminate(false);
      // Show progressdialog
      mProgressDialog.show();
    }
    
    @Override
    protected Void doInBackground(Void...params) {
      // Create an array
      try {
  
        //String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        httpHandler handler = new httpHandler();
        url = Parametros.confProtocol + "://" + Parametros.confHost + ":" + Parametros.confPort + "/ords/unionws/union/login/" + usuario + "/" + password;
        Log.i(TAG, url + "  url....");
        Log.i(TAG, "111111111");
        resp = handler.getLogin(url);
        
        Log.i(TAG, resp + " 0");
        
      } catch (Exception e) {
        e.printStackTrace();
      }
      return null;
    }
    
    @Override
    protected void onPostExecute(Void args) {
      try {
        mProgressDialog.dismiss();
        Log.i(TAG, resp + " 1");
        JSONObject respuestaJSON = new JSONObject(resp);
        
        String resultJSON = "1"; //respuestaJSON.getString("count");   // estado es el nombre del campo en el JSON
        
        Log.i(TAG, resultJSON);
        if (resultJSON.equals("1")) {
          JSONArray datosJSON = respuestaJSON.getJSONArray("items"); // estado es el nombre del campo en el JSON
          for (int i = 0; i < datosJSON.length(); i++) {
            
            String activo = datosJSON.getJSONObject(i).getString("VALIDO");
            
            if (activo.equals("S")) {
              activo = "SI";
              Log.i(TAG, " VALIDO " + activo);
              
              db.deleteLogin();
              
              Login user = new Login();
              
              user.setUserLogin(datosJSON.getJSONObject(i).getString("USER_LOGIN"));
              user.setUserName(datosJSON.getJSONObject(i).getString("USER_DESC"));
              user.setUserToken(datosJSON.getJSONObject(i).getString("USER_TOKE"));
              user.setUserEmplCodi(datosJSON.getJSONObject(i).getString("USER_EMPL_CODI"));
              user.setUserDepoCodi(datosJSON.getJSONObject(i).getString("USER_DEPO_CODI"));
              
              db.insertLogin(user);
              
              Login login = new Login();
              
              login = db.selectLogin();
              
              Parametros.userLogin = login.getUserLogin();
              Parametros.userName = login.getUserName();
              Parametros.userToken = login.getUserToken();
              Parametros.userEmplCodi = login.getUserEmplCodi();
              Parametros.userDepoCodi = login.getUserDepoCodi();
              
              Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
              
              startActivity(intent);
              
              finish();
              
            } else {
              activo = "NO";
              Log.i(TAG, " valido " + activo);
              AlertDialog alertDialog = new AlertDialog.Builder(LoginActivity.this).create();
              alertDialog.setTitle("Atención");
              alertDialog.setMessage("Autenticación Inválida");
              alertDialog.show();
              
            }
          }
          
        } else if (resultJSON.equals("-1")) {
          AlertDialog alertDialog = new AlertDialog.Builder(LoginActivity.this).create();
          
          // Setting Dialog Title
          alertDialog.setTitle("Atención");
          
          // Setting Dialog Message
          alertDialog.setMessage("Tiempo de espera agotado.");
          
          // Setting Icon to Dialog
          //alertDialog.setIcon(R.drawable.ic_launcher_background);
          
          // Showing Alert Message
          alertDialog.show();
        } else {
          //Toast.makeText(view.getContext(),"@string/msgErrorAut", Toast.LENGTH_SHORT).show();
          
          AlertDialog alertDialog = new AlertDialog.Builder(LoginActivity.this).create();
          
          // Setting Dialog Title
          alertDialog.setTitle("Atención");
          
          // Setting Dialog Message
          alertDialog.setMessage("Error de autenticación");
          
          // Setting Icon to Dialog
          //alertDialog.setIcon(R.drawable.ic_launcher_background);
          
          // Showing Alert Message
          alertDialog.show();
        }
        // Close the progressdialog
        
      } catch (JSONException e) {
        AlertDialog alertDialog = new AlertDialog.Builder(LoginActivity.this).create();
        alertDialog.setTitle("Atención");
        alertDialog.setMessage("Conexión Inválida");
        alertDialog.show();
        
        e.printStackTrace();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
}