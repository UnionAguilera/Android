package py.com.unionsrl.labot;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class AdapterEntm extends BaseAdapter {
  private static final String TAG = "AdapterTpot";
  private Context context;
  private ArrayList<TrasOt> listItems;
  
  public AdapterEntm(Context context, ArrayList<TrasOt> listItems) {
    
    this.context = context;
    this.listItems = listItems;
  }
  
  @Override
  public int getCount() {
    return listItems.size();
  }
  
  @Override
  public Object getItem(int position) {
    return listItems.get(position);
  }
  
  @Override
  public long getItemId(int position) {
    return Long.parseLong(listItems.get(position).getTpotNroOt().toString());
  }
  
  @Override
  public View getView(int position, View view, ViewGroup viewGroup) {
    TrasOt item = (TrasOt) getItem(position);
    
    view = LayoutInflater.from(context).inflate(R.layout.item_tpot, null);
    
    TextView txtItemTpotNroOt = (TextView) view.findViewById(R.id.txtItemTpotNroOt);
    TextView txtItemTpotEstado = (TextView) view.findViewById(R.id.txtItemTpotEstado);
    TextView txtItemTpotFecha = (TextView) view.findViewById(R.id.txtItemTpotFecha);
    TextView txtItemTpotTipoSolicitud = (TextView) view.findViewById(R.id.txtItemTpotTipoSolicitud);
    TextView txtItemTpotDeposito = (TextView) view.findViewById(R.id.txtItemTpotDeposito);
    TextView txtItemTpotDescDeposito = (TextView) view.findViewById(R.id.txtItemTpotDescDeposito);
    
    
    txtItemTpotNroOt.setText("Nro OT: " + item.getTpotNroOt());
    txtItemTpotEstado.setText("Estado: " + item.getTpotEstado());
    txtItemTpotFecha.setText("Fecha: " + item.getTpotFecha());
    if (item.getTpotEstado().equalsIgnoreCase("P")) {
      txtItemTpotEstado.setTextColor(ContextCompat.getColor(this.context, R.color.colorSecondPrimaryDark));
      txtItemTpotEstado.setText("Estado: Pendiente");
    } else {
      txtItemTpotEstado.setTextColor(ContextCompat.getColor(this.context, R.color.colorSecondAccent));
      txtItemTpotEstado.setText("Estado: Liquidado");
    }

    if (item.getTpotSolicitud().equalsIgnoreCase("N")){
      txtItemTpotTipoSolicitud.setTextColor(ContextCompat.getColor(this.context, android.R.color.black));
      txtItemTpotTipoSolicitud.setText("Tipo Solic.: Normal");
    }else if (item.getTpotSolicitud().equalsIgnoreCase("A")){
      txtItemTpotTipoSolicitud.setTextColor(ContextCompat.getColor(this.context, android.R.color.holo_blue_dark));
      txtItemTpotTipoSolicitud.setText("Tipo Solic.: Adicional");
    }else{
      txtItemTpotTipoSolicitud.setText("Tipo Solic.: ****");
    }
    
    txtItemTpotDeposito.setText("Nro depo.: " + item.getTpotDeposito());
    txtItemTpotDescDeposito.setText("Depósito: " + item.getTpotDescDeposito());
    
    Log.d(TAG, "Position " + position + " OT " + item.getTpotNroOt() + " Estado " + item.getTpotEstado());
    
    return view;
  }
}