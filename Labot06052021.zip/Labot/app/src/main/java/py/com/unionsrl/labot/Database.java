package py.com.unionsrl.labot;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {
  
  public static final int DATABASE_VERSION = 10;
  public static final String DATABASE_NAME = "appapex.db";
  private static final String TAG = "Database";
  
  public Database(Context context) {
    super(context, DATABASE_NAME, null, DATABASE_VERSION);
  }
  
  @Override
  
  public void onCreate(SQLiteDatabase sqLiteDatabase) {
    sqLiteDatabase.execSQL("CREATE TABLE " + py.com.unionsrl.labot.DbContract.Tables.LOGIN + " (" +
        py.com.unionsrl.labot.DbContract.LoginColumns.userlogin + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.LoginColumns.userName + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.LoginColumns.userToken + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.LoginColumns.userEmplCodi + " TEXT," +
        py.com.unionsrl.labot.DbContract.LoginColumns.userDepoCodi + " TEXT" +
        " ) ");
    //sqLiteDatabase.execSQL("DROP TABLE LABO_TRAS_OT");
    sqLiteDatabase.execSQL("CREATE TABLE " + py.com.unionsrl.labot.DbContract.Tables.CONFIG + " (" +
        py.com.unionsrl.labot.DbContract.ConfigColumns.confProtocol + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.ConfigColumns.confHost + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.ConfigColumns.confPort + " TEXT NOT NULL" +
        " )");
    
    sqLiteDatabase.execSQL("CREATE TABLE " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT + " (" +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " INTEGER NOT NULL," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud + " TEXT ," +
            DbContract.TrasOtColumns.tpotFecha+ " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito + " INTEGER NOT NULL," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDescDeposito + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo + " INTEGER," +
        DbContract.TrasOtColumns.tpotAlfanumerico + " TEXT NOT NULL," +
        DbContract.TrasOtColumns.tpotDescArticulo + " TEXT NOT NULL," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad + " INTEGER," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1 + " TEXT ," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1 + " TEXT ," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2 + " TEXT ," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2 + " TEXT ," +

        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor + " INTEGER ," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd + " INTEGER ," +
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado + " TEXT DEFAULT 'P'," +
            DbContract.TrasOtColumns.tpotIndEnvio + " TEXT DEFAULT 'N'"+
        " )");
        
  }
  
  @Override
  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    Log.d(TAG, "Upgrading database from version " + oldVersion + " to " +
        newVersion + ", which will destroy all old data");
    db.execSQL("DROP TABLE IF EXISTS " + py.com.unionsrl.labot.DbContract.Tables.LOGIN);
    db.execSQL("DROP TABLE IF EXISTS " + py.com.unionsrl.labot.DbContract.Tables.CONFIG);
    db.execSQL("DROP TABLE IF EXISTS " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT);
    
    onCreate(db);
  }
  
  public void insertLogin(Login login) {
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues values = new ContentValues();
    
    values.put(py.com.unionsrl.labot.DbContract.LoginColumns.userlogin, login.getUserLogin());
    values.put(py.com.unionsrl.labot.DbContract.LoginColumns.userName, login.getUserName());
    values.put(py.com.unionsrl.labot.DbContract.LoginColumns.userToken, login.getUserToken());
    values.put(py.com.unionsrl.labot.DbContract.LoginColumns.userEmplCodi, login.getUserEmplCodi());
    values.put(py.com.unionsrl.labot.DbContract.LoginColumns.userDepoCodi, login.getUserDepoCodi());
    
    db.insert(py.com.unionsrl.labot.DbContract.Tables.LOGIN, null, values);
    Log.d(TAG, "Login Insertado " + login.toString());
    db.close();
  }
  
  public int deleteLogin() {
    
    return getWritableDatabase().delete(
        py.com.unionsrl.labot.DbContract.Tables.LOGIN,
        null,
        null);
  }
  
  public Login selectLogin() {
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor c = db.rawQuery("SELECT * FROM " + py.com.unionsrl.labot.DbContract.Tables.LOGIN, null);
    Login login = mapearLogin(c);
    c.close();
    db.close();
    return login;
  }
  
  private Login mapearLogin(Cursor cursor) {
    Login login = new Login();
    if (cursor.moveToFirst()) {
      login.setUserLogin(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.LoginColumns.userlogin)));
      login.setUserName(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.LoginColumns.userName)));
      login.setUserToken(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.LoginColumns.userToken)));
      login.setUserEmplCodi(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.LoginColumns.userEmplCodi)));
      login.setUserDepoCodi(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.LoginColumns.userDepoCodi)));
    }
    return login;
  }
  
  public void insertConfig(Config config) {
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues values = new ContentValues();
    
    values.put(py.com.unionsrl.labot.DbContract.ConfigColumns.confProtocol, config.getConfProtocol());
    values.put(py.com.unionsrl.labot.DbContract.ConfigColumns.confHost, config.getConfHost());
    values.put(py.com.unionsrl.labot.DbContract.ConfigColumns.confPort, config.getConfPort());
    
    db.insert(py.com.unionsrl.labot.DbContract.Tables.CONFIG, null, values);
    Log.d(TAG, "Config Insertado " + config.toString());
    
    db.close();
    
  }
  
  public int deleteConfig() {
    return getWritableDatabase().delete(
        py.com.unionsrl.labot.DbContract.Tables.CONFIG,
        null,
        null);
  }
  
  public Config selectConfig() {
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor c = db.rawQuery("SELECT * FROM " + py.com.unionsrl.labot.DbContract.Tables.CONFIG, null);
    Config config = mapearConfig(c);
    c.close();
    db.close();
    return config;
  }
  
  private Config mapearConfig(Cursor cursor) {
    Config config = new Config();
    if (cursor.moveToFirst()) {
      config.setConfProtocol(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.ConfigColumns.confProtocol)));
      config.setConfHost(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.ConfigColumns.confHost)));
      config.setConfPort(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.ConfigColumns.confPort)));
      
    }
    return config;
  }

  public void insertTpot(TrasOt tpot) {
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues values = new ContentValues();
    
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt, tpot.getTpotNroOt());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud, tpot.getTpotSolicitud());
    values.put(DbContract.TrasOtColumns.tpotFecha, tpot.getTpotFecha());

    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito, tpot.getTpotDeposito());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDescDeposito, tpot.getTpotDescDeposito());

    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo, tpot.getTpotArticulo());
    values.put(DbContract.TrasOtColumns.tpotAlfanumerico, tpot.getTpotAlfanumerico());
    values.put(DbContract.TrasOtColumns.tpotDescArticulo, tpot.getTpotDescArticulo());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad, tpot.getTpotCantidad());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1, tpot.getTpotLote1());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1, tpot.getTpotCantidad1());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2, tpot.getTpotLote2());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2, tpot.getTpotCantidad2());

    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor, tpot.getTpotPreparadoPor());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd, tpot.getTpotClaveEntregaPrd());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado, tpot.getTpotEstado());
    values.put(DbContract.TrasOtColumns.tpotIndEnvio, tpot.getTpotIndEnvio());
    
    db.insert(py.com.unionsrl.labot.DbContract.Tables.TRAS_OT, null, values);
    Log.d(TAG, "Tpot Insertado " + tpot.toString());
    db.close();
  }
  

  public void updateTpot(TrasOt tpot) {
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues values = new ContentValues();
    
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt, tpot.getTpotNroOt());
    //values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito, tpot.getTpotDeposito());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo, tpot.getTpotArticulo());
    //values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad, tpot.getTpotCantidad());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1, tpot.getTpotLote1());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1, tpot.getTpotCantidad1());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2, tpot.getTpotLote2());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2, tpot.getTpotCantidad2());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud, tpot.getTpotSolicitud());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor, tpot.getTpotPreparadoPor());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd, tpot.getTpotClaveEntregaPrd());
    values.put(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado, tpot.getTpotEstado());
    
    String[] whereArgs = {
        tpot.getTpotNroOt().toString(), tpot.getTpotArticulo().toString()
    };
    
    db.update(py.com.unionsrl.labot.DbContract.Tables.TRAS_OT, values, py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " = ? and "+DbContract.TrasOtColumns.tpotArticulo+" = ?", whereArgs);
    Log.d(TAG, "Tpot Actualizado " + tpot.getTpotEstado());
    db.close();
  }
  
  public int deleteTrasOtByNro(int tpotNroOt) {
    String[] whereArgs = {
        String.valueOf(tpotNroOt)
    };
    return getWritableDatabase().delete(
        py.com.unionsrl.labot.DbContract.Tables.TRAS_OT,
        py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " = ?",
        whereArgs);
  }
  
  public int deleteTrasOtPend() {
    
    return getWritableDatabase().delete(
        py.com.unionsrl.labot.DbContract.Tables.TRAS_OT,
        "IFNULL(" + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud + ",'N') like 'N' ",
        null);
  }
  
  public TrasOt selectTrasOtByCodi(String tpotNroOt, String tpotArticulo) {
    SQLiteDatabase db = this.getReadableDatabase();
    String sql = "SELECT * FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT +
        " where " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " = ? and "+DbContract.TrasOtColumns.tpotArticulo +" = ?";
    String[] whereArgs = {
        tpotNroOt, tpotArticulo
    };
    Cursor c = db.rawQuery(sql, whereArgs);
    TrasOt tpot = mapearTpot(c);
    c.close();
    db.close();
    return tpot;
  }
  
  public TrasOt selectTrasOtByNroOt(Integer tpotNroOt) {
    SQLiteDatabase db = this.getReadableDatabase();
    String sql = "SELECT * FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT +
                 " where " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " = ?";

    String[] whereArgs = {
        tpotNroOt.toString()
    };
    Log.d(TAG, "Cursor selectTrasOtByNroOt " + sql + ", + " + tpotNroOt.toString() );
    Cursor c = db.rawQuery(sql, whereArgs);
    TrasOt tpot = mapearTpot(c);
    c.close();
    db.close();
    return tpot;
  }
  
  public ArrayList<TrasOt> enviarTrasOtByNroOt(Integer tpotNroOt) {
    SQLiteDatabase db = this.getReadableDatabase();
    String sql = "SELECT * FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT +
                 " where " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " = ?";
    String[] whereArgs = {
        tpotNroOt.toString()
    };
    
    
    Log.d(TAG, "Cursor enviarTrasOtByNroOt " + sql + ", + " + tpotNroOt.toString() );
    Cursor c ;
  
  
    c = db.rawQuery(sql, whereArgs);
  
  
    ArrayList<TrasOt> list = new ArrayList<>();
    if (c.moveToFirst()) {
      do {
        TrasOt t = new TrasOt(
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotFecha)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescDeposito)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotAlfanumerico)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescArticulo)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotIndEnvio))
        );
        list.add(t);
      } while (c.moveToNext());
    }
    
    c.close();
    db.close();
    return list;
  }
  
  
  public ArrayList<TrasOt> selectAllTrasOt(String busqueda) {
    SQLiteDatabase db = this.getReadableDatabase();
    String sql = "";
    Cursor c;

    if (busqueda.length() == 0) {
      sql = " SELECT DISTINCT "+DbContract.TrasOtColumns.tpotNroOt+","+
              DbContract.TrasOtColumns.tpotSolicitud+","+
              DbContract.TrasOtColumns.tpotFecha+","+
              DbContract.TrasOtColumns.tpotEstado+","+
              DbContract.TrasOtColumns.tpotDeposito+","+
              DbContract.TrasOtColumns.tpotDescDeposito+","+
              DbContract.TrasOtColumns.tpotIndEnvio+
              " FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT;
    } else {
      sql = " SELECT DISTINCT "+DbContract.TrasOtColumns.tpotNroOt+","+
                            DbContract.TrasOtColumns.tpotSolicitud+","+
                            DbContract.TrasOtColumns.tpotFecha+","+
                            DbContract.TrasOtColumns.tpotEstado+","+
                            DbContract.TrasOtColumns.tpotDeposito+","+
                            DbContract.TrasOtColumns.tpotDescDeposito+","+
                            DbContract.TrasOtColumns.tpotIndEnvio+
              " FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT +
              " where (" + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud + " like '%" + busqueda + "%'" +
              " or " + DbContract.TrasOtColumns.tpotEstado + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1 + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2 + " like '%" + busqueda + "%'" +
              ")";
    }
    c = db.rawQuery(sql, null);

    ArrayList<TrasOt> list = new ArrayList<>();
    if (c.moveToFirst()) {
      do {
        TrasOt t = new TrasOt(
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotFecha)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescDeposito)),
            null,//c.getInt(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo)),
            null,//c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotAlfanumerico)),
            null,//c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescArticulo)),
            null,//c.getInt(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad)),
            null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1)),
            null,//c.getInt(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1)),
            null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2)),
            null,//c.getInt(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2)),

            null,//c.getInt(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor)),
            null,//c.getInt(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd)),
            c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado)),
            c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotIndEnvio))
        );
        list.add(t);
      } while (c.moveToNext());
    }
    c.close();
    db.close();
    return list;
  }
  

  public ArrayList<TrasOt> selectTrasOtArticulos(String NroOt) {
    SQLiteDatabase db = this.getReadableDatabase();
    String sql = " SELECT * FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT +
                 " where " +DbContract.TrasOtColumns.tpotNroOt + " = "+NroOt;
    //String[] whereArgs = {ortrCodi};
    Cursor c = db.rawQuery(sql, null);
    ArrayList<TrasOt> list = new ArrayList<>();
    if (c.moveToFirst()) {
      do {
        TrasOt t = new TrasOt(
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotFecha)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescDeposito)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotAlfanumerico)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescArticulo)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2)),

                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotIndEnvio))
        );
        list.add(t);
      } while (c.moveToNext());
    }
    c.close();
    db.close();
    return list;
  }
  
 
  public ArrayList<TrasOt> selectTrasOtIndiEnvi(String envi, String busqueda) {
    SQLiteDatabase db = this.getReadableDatabase();
    String sql = "";
    String[] whereArgs = {
        envi
    };
    Cursor c;
    
    if (busqueda.length() == 0) {
      sql = " SELECT DISTINCT "+DbContract.TrasOtColumns.tpotNroOt+","+
                            DbContract.TrasOtColumns.tpotSolicitud+","+
                            DbContract.TrasOtColumns.tpotFecha+","+
                            DbContract.TrasOtColumns.tpotEstado+","+
                            DbContract.TrasOtColumns.tpotDeposito+","+
                            DbContract.TrasOtColumns.tpotDescDeposito+
              " FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT +
          " where ifnull(" + DbContract.TrasOtColumns.tpotIndEnvio + ",'N') = ?";
      
      c = db.rawQuery(sql, whereArgs);
    } else {
      sql = " SELECT DISTINCT "+DbContract.TrasOtColumns.tpotNroOt+","+
                                          DbContract.TrasOtColumns.tpotSolicitud+","+
                                          DbContract.TrasOtColumns.tpotFecha+","+
                                          DbContract.TrasOtColumns.tpotEstado+","+
                                          DbContract.TrasOtColumns.tpotDeposito+","+
                                          DbContract.TrasOtColumns.tpotDescDeposito+
              " FROM " + py.com.unionsrl.labot.DbContract.Tables.TRAS_OT + " where ifnull(" + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotIndEnvio + ",'N') = ?" +
          " and (" + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud + " like '%" + busqueda + "%'" +
              " or " + DbContract.TrasOtColumns.tpotEstado + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1 + " like '%" + busqueda + "%'" +
              " or " + py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2 + " like '%" + busqueda + "%'" +
          ")";
      c = db.rawQuery(sql, whereArgs);
    }
    
    ArrayList<TrasOt> list = new ArrayList<>();
    if (c.moveToFirst()) {
      do {
        TrasOt t = new TrasOt(
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotFecha)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescDeposito)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo)),
                null,//c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotAlfanumerico)),
                null,//c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotDescArticulo)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2)),

                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor)),
                null,//c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd)),
                c.getString(c.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado)),
                c.getString(c.getColumnIndex(DbContract.TrasOtColumns.tpotIndEnvio))
        );
        list.add(t);
      } while (c.moveToNext());
    }
    c.close();
    db.close();
    return list;
  }

  
  
  private TrasOt mapearTpot(Cursor cursor) {
    TrasOt tpot = new TrasOt();
    if (cursor.moveToFirst()) {
      tpot.setTpotNroOt(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotNroOt)));
      tpot.setTpotSolicitud(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotSolicitud)));
      tpot.setTpotFecha(cursor.getString(cursor.getColumnIndex(DbContract.TrasOtColumns.tpotFecha)));

      tpot.setTpotDeposito(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotDeposito)));
      tpot.setTpotDescDeposito(cursor.getString(cursor.getColumnIndex(DbContract.TrasOtColumns.tpotDescDeposito)));

      tpot.setTpotArticulo(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotArticulo)));
      tpot.setTpotAlfanumerico(cursor.getString(cursor.getColumnIndex(DbContract.TrasOtColumns.tpotAlfanumerico)));
      tpot.setTpotDescArticulo(cursor.getString(cursor.getColumnIndex(DbContract.TrasOtColumns.tpotDescArticulo)));

      tpot.setTpotCantidad(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad)));
      tpot.setTpotLote1(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote1)));
      tpot.setTpotCantidad1(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad1)));
      tpot.setTpotLote2(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotLote2)));
      tpot.setTpotCantidad2(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotCantidad2)));

      tpot.setTpotPreparadoPor(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotPreparadoPor)));
      tpot.setTpotClaveEntregaPrd(cursor.getInt(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotClaveEntregaPrd)));
      tpot.setTpotEstado(cursor.getString(cursor.getColumnIndex(py.com.unionsrl.labot.DbContract.TrasOtColumns.tpotEstado)));
    }
    return tpot;
  }
  
}