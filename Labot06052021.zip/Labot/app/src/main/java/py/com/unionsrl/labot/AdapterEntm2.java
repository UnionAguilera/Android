package py.com.unionsrl.labot;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class AdapterEntm2 extends BaseAdapter {
  private static final String TAG = "AdapterTpot";
  private Context context;
  private ArrayList<TrasOt> listItems;

  public AdapterEntm2(Context context, ArrayList<TrasOt> listItems) {
    
    this.context = context;
    this.listItems = listItems;
  }
  
  @Override
  public int getCount() {
    return listItems.size();
  }
  
  @Override
  public Object getItem(int position) {
    return listItems.get(position);
  }
  
  @Override
  public long getItemId(int position) {
    return Long.parseLong(listItems.get(position).getTpotNroOt().toString());
  }
  
  @Override
  public View getView(int position, View view, ViewGroup viewGroup) {
    TrasOt item = (TrasOt) getItem(position);
    
    view = LayoutInflater.from(context).inflate(R.layout.item_tpot2, null);
    
    TextView txtItemTpotNroOt = (TextView) view.findViewById(R.id.txtItemTpotNroOt2);
    TextView txtItemTpotEstado = (TextView) view.findViewById(R.id.txtItemTpotEstado2);
    TextView txtItemTpotArticulo = (TextView) view.findViewById(R.id.txtItemTpotArticulo);
    TextView txtItemTpotCantidad = (TextView) view.findViewById(R.id.txtItemTpotCantidad);
    TextView txtItemTpotDescArticulo = (TextView) view.findViewById(R.id.txtItemTpotDescArticulo);
    TextView txtItemTpotLote1 = (TextView) view.findViewById(R.id.txtItemTpotLote1);
    TextView txtItemTpotCantidad1 = (TextView) view.findViewById(R.id.txtItemTpotCantidad1);
    TextView txtItemTpotLote2 = (TextView) view.findViewById(R.id.txtItemTpotLote2);
    TextView txtItemTpotCantidad2 = (TextView) view.findViewById(R.id.txtItemTpotCantidad2);
    
    
    txtItemTpotNroOt.setText("Nro OT: " + item.getTpotNroOt());
    txtItemTpotEstado.setText(/*"Estado: " + item.getTpotEstado()*/"");
    txtItemTpotArticulo.setText("Cód.: " + item.getTpotArticulo());
    txtItemTpotCantidad.setText("Cantidad: " + item.getTpotCantidad());
    txtItemTpotDescArticulo.setText("Art.: " + item.getTpotAlfanumerico()+" - "+item.getTpotDescArticulo());
    /*if (item.getTpotEstado().equalsIgnoreCase("P")) {
      txtItemTpotEstado.setTextColor(ContextCompat.getColor(this.context, R.color.colorSecondPrimaryDark));
      txtItemTpotEstado.setText("Estado: Pendiente");
    } else {
      txtItemTpotEstado.setTextColor(ContextCompat.getColor(this.context, R.color.colorSecondAccent));
      txtItemTpotEstado.setText("Estado: Liquidado");
    }*/

    txtItemTpotLote1.setText(item.getTpotLote1());
    if(txtItemTpotLote1.length()!=0){
      txtItemTpotLote1.setText("Lote1: " + item.getTpotLote1());
      txtItemTpotCantidad1.setText("Cantidad1: " + item.getTpotCantidad1());
    }else{
      txtItemTpotLote1.setText("Lote1: ");
      txtItemTpotCantidad1.setText("Cantidad1: ");
    }

    txtItemTpotLote2.setText(item.getTpotLote2());
    if(txtItemTpotLote2.length()!=0){
      txtItemTpotLote2.setText("Lote2: " + item.getTpotLote2());
      txtItemTpotCantidad2.setText("Cantidad2: " + item.getTpotCantidad2());
    }else{
      txtItemTpotLote2.setText("Lote2: ");
      txtItemTpotCantidad2.setText("Cantidad2: ");
    }

    
    Log.d(TAG, "Position " + position + " OT " + item.getTpotNroOt() + " Estado " + item.getTpotEstado());
    
    return view;
  }
}