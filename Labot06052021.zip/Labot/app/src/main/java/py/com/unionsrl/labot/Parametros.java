package py.com.unionsrl.labot;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

public class Parametros {
    public static String userToken;
    public static String userName;
    public static String userLogin;
    public static String userEmplCodi;
    public static String confProtocol;
    public static String userDepoCodi;
    public static String confHost;
    public static String confPort;

    public static void showToast(String msj, Context ctx) {
        if (!msj.isEmpty()) {
            Toast t = Toast.makeText(ctx, msj
                    , Toast.LENGTH_LONG);
            t.setGravity(Gravity.CENTER | Gravity.BOTTOM, 0, 0);
            t.show();
        }
    }
}
