package py.com.unionsrl.labot;
import java.util.ArrayList;

public class TrasOt {
  private Integer tpotNroOt;
  private String tpotSolicitud;
  private String tpotFecha;
  private Integer tpotDeposito;
  private String tpotDescDeposito;
  private Integer tpotArticulo;
  private String tpotAlfanumerico;
  private String tpotDescArticulo;
  private Integer tpotCantidad;
  private String tpotLote1;
  private Integer tpotCantidad1;
  private String tpotLote2;
  private Integer tpotCantidad2;

  private Integer tpotPreparadoPor;
  private Integer tpotClaveEntregaPrd;
  private String tpotEstado;
  private String tpotIndEnvio;
  
  public TrasOt() {
  
  }
  
  public TrasOt(String tpotNroOt, String tpotSolicitud, String tpotFecha, String tpotDeposito, String tpotDescDeposito, String tpotArticulo,
                String tpotAlfanumerico, String tpotDescArticulo, String tpotCantidad, String tpotLote1, String tpotCantidad1, String tpotLote2,
                String tpotCantidad2, String tpotPreparadoPor, String tpotClaveEntregaPrd, String tpotEstado, String tpotIndEnvio) {
    this.tpotNroOt = Integer.valueOf(tpotNroOt);
    this.tpotSolicitud = tpotSolicitud;
    this.tpotFecha = tpotFecha;
    this.tpotDeposito = Integer.valueOf(tpotDeposito);
    this.tpotDescDeposito = tpotDescDeposito;
    this.tpotArticulo = Integer.valueOf(tpotArticulo);
    this.tpotAlfanumerico = tpotAlfanumerico;
    this.tpotDescArticulo = tpotDescArticulo;
    this.tpotCantidad = Integer.valueOf(tpotCantidad);
    this.tpotLote1 = tpotLote1;
    this.tpotCantidad1 = Integer.valueOf(tpotCantidad1);
    this.tpotLote2 = tpotLote2;
    this.tpotCantidad2 = Integer.valueOf(tpotCantidad2);

    this.tpotPreparadoPor = Integer.valueOf(tpotPreparadoPor);
    this.tpotClaveEntregaPrd = Integer.valueOf(tpotClaveEntregaPrd);
    this.tpotEstado = tpotEstado;
    this.tpotIndEnvio = tpotIndEnvio;
  }

  private ArrayList <TrasOt> getArrayOrdeTrab(ArrayList <TrasOt> list) {
    return list;
  }
  public Integer getTpotNroOt() {
    return tpotNroOt;
  }
  public void setTpotNroOt(Integer tpotNroOt) {
    this.tpotNroOt = tpotNroOt;
  }
  public Integer getTpotDeposito() {
    return tpotDeposito;
  }
  public void setTpotDeposito(Integer tpotDeposito) {
    this.tpotDeposito = tpotDeposito;
  }
  public Integer getTpotArticulo() {
    return tpotArticulo;
  }
  public void setTpotArticulo(Integer tpotArticulo) {
    this.tpotArticulo = tpotArticulo;
  }
  public Integer getTpotCantidad() {
    return tpotCantidad;
  }
  public void setTpotCantidad(Integer tpotCantidad) {
    this.tpotCantidad = tpotCantidad;
  }
  public String getTpotLote1() {
    return tpotLote1;
  }
  public void setTpotLote1(String tpotLote1) {
    this.tpotLote1 = tpotLote1;
  }
  public Integer getTpotCantidad1() {
    return tpotCantidad1;
  }
  public void setTpotCantidad1(Integer tpotCantidad1) {
    this.tpotCantidad1 = tpotCantidad1;
  }
  public String getTpotLote2() {
    return tpotLote2;
  }
  public void setTpotLote2(String tpotLote2) {
    this.tpotLote2 = tpotLote2;
  }
  public Integer getTpotCantidad2() {
    return tpotCantidad2;
  }
  public void setTpotCantidad2(Integer tpotCantidad2) {
    this.tpotCantidad2 = tpotCantidad2;
  }
  public String getTpotSolicitud() {
    return tpotSolicitud;
  }
  public void setTpotSolicitud(String tpotSolicitud) {
    this.tpotSolicitud = tpotSolicitud;
  }
  public Integer getTpotPreparadoPor() {
    return tpotPreparadoPor;
  }
  public void setTpotPreparadoPor(Integer tpotPreparadoPor) {
    this.tpotPreparadoPor = tpotPreparadoPor;
  }
  public Integer getTpotClaveEntregaPrd() {
    return tpotClaveEntregaPrd;
  }
  public void setTpotClaveEntregaPrd(Integer tpotClaveEntregaPrd) {
    this.tpotClaveEntregaPrd = tpotClaveEntregaPrd;
  }
  public String getTpotEstado() {
    return tpotEstado;
  }
  public void setTpotEstado(String tpotEstado) {
    this.tpotEstado = tpotEstado;
  }

  public String getTpotFecha() {
    return tpotFecha;
  }

  public void setTpotFecha(String tpotFecha) {
    this.tpotFecha = tpotFecha;
  }

  public String getTpotDescDeposito() {
    return tpotDescDeposito;
  }

  public void setTpotDescDeposito(String tpotDescDeposito) {
    this.tpotDescDeposito = tpotDescDeposito;
  }

  public String getTpotAlfanumerico() {
    return tpotAlfanumerico;
  }

  public void setTpotAlfanumerico(String tpotAlfanumerico) {
    this.tpotAlfanumerico = tpotAlfanumerico;
  }

  public String getTpotDescArticulo() {
    return tpotDescArticulo;
  }

  public void setTpotDescArticulo(String tpotDescArticulo) {
    this.tpotDescArticulo = tpotDescArticulo;
  }

  public String getTpotIndEnvio() {
    return tpotIndEnvio;
  }

  public void setTpotIndEnvio(String tpotIndEnvio) {
    this.tpotIndEnvio = tpotIndEnvio;
  }
}