package py.com.unionsrl.labot;


public class Login {
    private String userLogin;
    private String userName;
    private String userToken;
    private String userEmplCodi;
    private String userDepoCodi;

    public Login() {
        this.userLogin = userLogin;
        this.userName = userName;
        this.userToken = userToken;
        this.userEmplCodi = userEmplCodi;
        this.userDepoCodi = userDepoCodi;
    }

    public Login(String userLogin, String userName, String userToken, String userEmplCodi, String userDepoCodi) {
        this.userLogin = userLogin;
        this.userName = userName;
        this.userToken = userToken;
        this.userEmplCodi = userEmplCodi;
        this.userDepoCodi = userDepoCodi;
    }


    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    public String getUserEmplCodi() {
        return userEmplCodi;
    }

    public void setUserEmplCodi(String userEmplCodi) {
        this.userEmplCodi = userEmplCodi;
    }

    public String getUserDepoCodi() {
        return userDepoCodi;
    }

    public void setUserDepoCodi(String userDepoCodi) {
        this.userDepoCodi = userDepoCodi;
    }
}
