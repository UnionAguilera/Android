package py.com.unionsrl.labot;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SyncActivity extends AppCompatActivity {
  
  private final String TAG = "SyncActivity";
  private Button btnSyncAll;
  private Database db = new Database(this);
  ProgressDialog mProgressDialog;
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_sync);
    btnSyncAll = (Button) findViewById(R.id.btnSyncAll);
    setupBtnSyncAll();
  }
  
  private void setupBtnSyncAll() {
    btnSyncAll.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        new py.com.unionsrl.labot.SyncActivity.Syncroniza().execute();
      }
    });
  }
  
  private class Syncroniza extends AsyncTask<Void, Void, Void> {
    private String respSyncOT;
    private String respSyncStocLote;
    private String respSyncStocVehi;
    
    @Override
    protected void onPreExecute() {
      super.onPreExecute();
      // Create a progressdialog
      mProgressDialog = new ProgressDialog(py.com.unionsrl.labot.SyncActivity.this);
      // Set progressdialog title
      mProgressDialog.setTitle("Espere un momento");
      // Set progressdialog message
      mProgressDialog.setMessage("Abriendo...");
      mProgressDialog.setIndeterminate(false);
      // Show progressdialog
      mProgressDialog.show();
    }
    
    @Override
    protected Void doInBackground(Void... params) {
      // Create an array
      try {
        
        sincronizaOt();
        
      } catch (Exception e) {
        e.printStackTrace();
      }
      return null;
    }
    
    @Override
    protected void onPostExecute(Void args) {
      try {
        mProgressDialog.dismiss();
        
        postSincronizaOt();
        Parametros.showToast("Datos sincronizados con éxito. ", py.com.unionsrl.labot.SyncActivity.this);
        
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    
    private void sincronizaOt() {
      try {
        
        httpHandler handler = new httpHandler();
        //String url = Parametros.confProtocol + "://" + Parametros.confHost + ":" + Parametros.confPort + "/ords/unionws/union/tpot/" + Parametros.userToken + "/" + Parametros.userDepoCodi;
        String url = "http://192.168.0.137/apiLaboRest/ws_data/get_solicitudes_pendientes.php?p_deposito=10";
        respSyncOT = handler.getOrdeTrab(url);
        
        Log.i(TAG, "Background get ot resp " + respSyncOT);
        
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    
    private void postSincronizaOt() {
      try {
        //mProgressDialog.dismiss();
        Log.i(TAG, "POST SYNC OT resp " + respSyncOT);
        JSONObject respuestaJSON = new JSONObject(respSyncOT.toString().replaceAll("[^\\x00-\\x7F]", ""));
        
        String resultJSON = "S";//respuestaJSON.getString("valido"); // estado es el nombre del campo en el JSON
        String resultToken = "S";//respuestaJSON.getString("vali_toke");
        
        Log.i(TAG, "POST SYNC OT RESULTJSON " + resultJSON);
        if (resultJSON.equals("S")) {
          
          int idb = db.deleteTrasOtPend();
          Log.d(TAG, "Borrando Ots " + idb);
          
          JSONArray datosJSON = respuestaJSON.getJSONArray("detalle"); // estado es el nombre del campo en el JSON

          Log.d(TAG, "Leyendo Json " + datosJSON.length());

          for (int i = 0; i < datosJSON.length(); i++) {
            
            TrasOt ot = new TrasOt();
            ot = db.selectTrasOtByNroOt(datosJSON.getJSONObject(i).getInt("SOPO_NRO_OT"));
            
            Log.d(TAG, "Verifica Ot " + ot.getTpotNroOt() + " tpotSolicitud " + ot.getTpotSolicitud() + " datosJSON.length() " + datosJSON.length());
            
            //if (ot.getTpotNroOt() == null) {
              
              TrasOt tpot = new TrasOt();
              
              tpot.setTpotNroOt(Integer.valueOf(datosJSON.getJSONObject(i).getInt("SOPO_NRO_OT")));
              tpot.setTpotSolicitud(String.valueOf(datosJSON.getJSONObject(i).getString("SOPO_SOLICITUD")));
              tpot.setTpotFecha(datosJSON.getJSONObject(i).getString("SOPO_FECHA_OT"));

              tpot.setTpotDeposito(Integer.valueOf(datosJSON.getJSONObject(i).getInt("SOPO_DEPOSITO")));
              tpot.setTpotDescDeposito(datosJSON.getJSONObject(i).getString("SOPO_DESCRIPCION_DEPOSITO"));

              tpot.setTpotArticulo(Integer.valueOf(datosJSON.getJSONObject(i).getInt("SOPO_ARTICULO")));
              tpot.setTpotAlfanumerico(datosJSON.getJSONObject(i).getString("SOPO_ALFANUMERICO"));
              tpot.setTpotDescArticulo(datosJSON.getJSONObject(i).getString("SOPO_DESCRIPCION"));

              tpot.setTpotCantidad(Integer.valueOf(datosJSON.getJSONObject(i).getInt("SOPO_CANTIDAD")));
              if(String.valueOf(datosJSON.getJSONObject(i).getString("SOPO_LOTE1")).length()>0){
                tpot.setTpotLote1(String.valueOf(datosJSON.getJSONObject(i).getString("SOPO_LOTE1")));
              }
              tpot.setTpotCantidad1(Integer.valueOf(datosJSON.getJSONObject(i).getInt("SOPO_CANTIDAD1")));
              if(String.valueOf(datosJSON.getJSONObject(i).getString("SOPO_LOTE2")).length()>0){
                tpot.setTpotLote2(String.valueOf(datosJSON.getJSONObject(i).getString("SOPO_LOTE2")));
              }
              tpot.setTpotCantidad2(Integer.valueOf(datosJSON.getJSONObject(i).getInt("SOPO_CANTIDAD2")));

              //tpot.setTpotEstado(String.valueOf(datosJSON.getJSONObject(i).getString("TPOT_ESTADO")));
              tpot.setTpotEstado(String.valueOf('P'));
              tpot.setTpotIndEnvio(String.valueOf('N'));//N=No enviado, S=Si enviado.
  
              Log.d(TAG, "insertando Ots " + tpot.getTpotNroOt() + " ot.getTpotNroOt() " + ot.getTpotNroOt());
              db.insertTpot(tpot);
            //}
            Log.d(TAG, "controlador Ots " +  " ot.getTpotNroOt() " + ot.getTpotNroOt());
          }
          
        } else if (resultJSON.equals("-1")) {
          AlertDialog alertDialog = new AlertDialog.Builder(py.com.unionsrl.labot.SyncActivity.this).create();
          
          // Setting Dialog Title
          alertDialog.setTitle("Atención");
          
          // Setting Dialog Message
          alertDialog.setMessage("Tiempo de espera agotado.");
          
          // Setting Icon to Dialog
          //alertDialog.setIcon(R.drawable.ic_launcher_background);
          
          // Showing Alert Message
          alertDialog.show();
        } else {
          //Toast.makeText(view.getContext(),"@string/msgErrorAut", Toast.LENGTH_SHORT).show();
          
          AlertDialog alertDialog = new AlertDialog.Builder(py.com.unionsrl.labot.SyncActivity.this).create();
          
          // Setting Dialog Title
          alertDialog.setTitle("Atención");
          
          // Setting Dialog Message
          if (resultToken.equalsIgnoreCase("N")) {
            alertDialog.setMessage("Error de autenticación, token inválido.");
          } else {
            alertDialog.setMessage("Error en el proceso.");
          }
          
          // Setting Icon to Dialog
          //alertDialog.setIcon(R.drawable.ic_launcher_background);
          
          // Showing Alert Message
          alertDialog.show();
        }
        // Close the progressdialog
        
      } catch (JSONException e) {
        AlertDialog alertDialog = new AlertDialog.Builder(py.com.unionsrl.labot.SyncActivity.this).create();
        alertDialog.setTitle("Atención");
        alertDialog.setMessage("Conexión Inválida o no se procesaron correctamente los datos.");
        alertDialog.show();
        
        e.printStackTrace();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    
  }
  
}