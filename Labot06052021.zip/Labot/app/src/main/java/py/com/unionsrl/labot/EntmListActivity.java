package py.com.unionsrl.labot;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class EntmListActivity extends AppCompatActivity {
  private static final String TAG = "EntmListActivity";
  private ListView lvTpotList;
  private AdapterEntm adaptador;
  private Database db = new Database(this);
  private ArrayList<TrasOt> lv;
  
  private Button btnListTpotBusc;
  /////20/02/2021 se declara para enviar al backend y actualizar en la base de datos
  private Button btnListTpotEnvi;
  private RadioButton rbAllListTpot;
  private RadioButton rbNoEnviListTpot;
  private RadioButton rbEnviListTpot;
  
  //////// strin para url beakend para enviar
  private String url = "";
  //// otro string para la respuesta del backend
  private String resp;
  //// necesitamos un array list para recuperar la ot pendientes
  ArrayList<TrasOt> tpotListPendEnvi;
  //// el array list vamos a convertir en jeyson para enviar
  JSONObject jsonTpotPendEnvi;
  ///// dialogo de progreso a nivel visual
  ProgressDialog mProgressDialog;
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_entm_list);

    lvTpotList = (ListView) findViewById(R.id.listTpot);
    ////////////// se usa para saber si es enviado o no enviado o todos
    btnListTpotEnvi = (Button) findViewById(R.id.btnListTpotEnvi);
    rbAllListTpot = (RadioButton) findViewById(R.id.rbAllListTpot);
    rbNoEnviListTpot = (RadioButton) findViewById(R.id.rbNoEnviListTpot);
    rbEnviListTpot = (RadioButton) findViewById(R.id.rbEnviListTpot);
    setupRbListTpotEnvi();
    ActualizarLista();
    // si o si tiene que estar en el oncreate para que se use y funcione
    setupLvTpotList();
    setupBtnListTpotEnvi();
  }
  ////////// metodo que escucha cual es el radio buton que se marco
  private void setupRbListTpotEnvi() {
    rbAllListTpot.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        boolean checked = ((RadioButton) v).isChecked();
        // Check which radiobutton was pressed
        if (checked) {
          // Do your coding
          
          ActualizarLista();
        }
        //else{
        // Do your coding
        //}
      }
    });
    rbNoEnviListTpot.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        boolean checked = ((RadioButton) v).isChecked();
        // Check which radiobutton was pressed
        if (checked) {
          // Do your coding
          ActualizarLista();
        }
        
      }
    });
    rbEnviListTpot.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        boolean checked = ((RadioButton) v).isChecked();
        // Check which radiobutton was pressed
        if (checked) {
          // Do your coding
          ActualizarLista();
        }
        
      }
    });
    
  }
  
  /////// escucha el listener  de enviar
  private void setupBtnListTpotEnvi() {
    btnListTpotEnvi.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        //new py.com.unionsrl.EntmListActivity.EnviaOts().execute();
        new py.com.unionsrl.labot.EntmListActivity.EnviaOts().execute();
      }
    });
    
  }
  
  public void ActualizarLista() {
    String busqueda = "";
    if (rbAllListTpot.isChecked() == true) { ///////si marcamos la casilla todos en el radio buton
      lv = db.selectAllTrasOt(busqueda);
    } else if (rbNoEnviListTpot.isChecked() == true) {
      lv = db.selectTrasOtIndiEnvi("N", busqueda);
    } else {
      lv = db.selectTrasOtIndiEnvi("S", busqueda);
    }
    adaptador = new AdapterEntm(this, lv);
    
    lvTpotList.setAdapter(adaptador);
  }
  //aca se llama al metodo para enviar el parametro del codigo de la ot escucha el clic y le manda la posicion
  private void setupLvTpotList() {
    lvTpotList.setOnItemClickListener((new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
        TrasOt item = lv.get(i);
        
        String tpotNroOt = item.getTpotNroOt().toString();
        
        iniciarTpot(tpotNroOt);
        
      }
    }));
  }
  //  se va usar en otro metodo.
  private void iniciarTpot(String tpotNroOt) {
    //Intent i = new Intent(this, EntmEditActivity.class);
    Intent i = new Intent(this, EntmList2Activity.class);
    
    if (!tpotNroOt.equals("0")) {
      
      Bundle extras = new Bundle();
      extras.putString("tpotNroOt", tpotNroOt); // carga el parametro  en una variable que le vamos a enviar
      
      i.putExtras(extras);
      
      startActivity(i); //envia ya los parametros para buscar la ot que seleccionamos en el click
    }
  }
  ///// METODO PRE EXISTENTE OVERRIDE EXTIENDE DE OTRA CLASE Y ACTUALIZA LA PANTALLA DE LISTADO DE OT PENDIENTES OCRESUMEN HACE ESO
  @Override
  public void onResume() {
    super.onResume();
    // put your code here...
    ActualizarLista();
    
  }
  
  ///// recupera el array list empieza a sacarle los datos y cargar en un objeto jeison
  
  public JSONObject tpotListToJson(ArrayList<TrasOt> tpots) throws JSONException {
    
    JSONObject jResult = new JSONObject();
    
    JSONArray jArray = new JSONArray();
    
    for (int i = 0; i < tpots.size(); i++) {
      JSONObject jGroup = new JSONObject();
      jGroup.put("TPOT_NRO_OT", tpots.get(i).getTpotNroOt());
      jGroup.put("TPOT_DEPOSITO", tpots.get(i).getTpotDeposito());
      jGroup.put("TPOT_ARTICULO", tpots.get(i).getTpotArticulo());
      jGroup.put("TPOT_CANTIDAD", tpots.get(i).getTpotCantidad());
      jGroup.put("TPOT_LOTE1", tpots.get(i).getTpotLote1());
      jGroup.put("TPOT_CANTIDAD1", tpots.get(i).getTpotCantidad1());
      jGroup.put("TPOT_LOTE2", tpots.get(i).getTpotLote2());
      jGroup.put("TPOT_CANTIDAD2", tpots.get(i).getTpotCantidad2());
      jGroup.put("TPOT_SOLICITUD", tpots.get(i).getTpotSolicitud());
      jGroup.put("TPOT_PREPARADO_POR", tpots.get(i).getTpotPreparadoPor());
      jGroup.put("TPOT_CLAVE_ENTREGA_PRD", tpots.get(i).getTpotClaveEntregaPrd());
      jGroup.put("TPOT_ESTADO", tpots.get(i).getTpotEstado());
      
      jArray.put(jGroup); /// ese array mete todo en una fila
    }
    
    jResult.put("tpot", jArray); // array dentro del jeison se llama tpot
    return jResult;
  }

  ///// en la misma clase esta para la sincronizacion del rest se hizo la misma cosa con el login
  private class EnviaOts extends AsyncTask<Void, Void, Void> {
    
    @Override
    ///// levantar el progres espiner
    protected void onPreExecute() {
      super.onPreExecute();
      // Create a progressdialog
      mProgressDialog = new ProgressDialog(py.com.unionsrl.labot.EntmListActivity.this);
      // Set progressdialog title
      mProgressDialog.setTitle("Espere un momento");
      // Set progressdialog message
      mProgressDialog.setMessage("Abriendo...");
      mProgressDialog.setIndeterminate(false);
      // Show progressdialog
      mProgressDialog.show();
      /// y ya empieza a funcionar
    }
    
    @Override
    protected Void doInBackground(Void... params) {
      // Create an array
      try {
        /// armamos la url llama a un link que esta en el servidor en esa ubicacion web
        httpHandler handler = new httpHandler();
        // url = Parametros.confProtocol + "://" + Parametros.confHost + ":" + Parametros.confPort + "/apex/walrusws/walrus/tpot/";
        url = Parametros.confProtocol + "://" + Parametros.confHost + ":" + Parametros.confPort + "/ords/unionws/union/tpot/" + Parametros.userToken + "/" + Parametros.userDepoCodi;
        ////// carga en el array list en un select cuando se haya editado y el indicador de inviado esta en N en este proceso selectTrasOtPendEnvi hace de una para todos
        //tpotListPendEnvi = db.selectTrasOtPendEnvi();
        tpotListPendEnvi = db.selectAllTrasOt("");
        ///// ese array list le envia al jeyson recorre la lista de acuerdo a su tamaño
        jsonTpotPendEnvi = tpotListToJson(tpotListPendEnvi);
  
        Log.i(TAG, "url SEND OT " + url);
        Log.i(TAG, "Background SEND OT " + jsonTpotPendEnvi.toString());
        
        /// ACA ENVIA COMO UN CUERPO
        resp = handler.getJSON(url, jsonTpotPendEnvi.toString(), 600000, "POST");
        
        Log.i(TAG, "Background get ot resp " + resp);
        
      } catch (Exception e) {
        e.printStackTrace();
      }
      return null;
    }
    
    @Override
    protected void onPostExecute(Void args) {
      try {
        mProgressDialog.dismiss();
        Log.i(TAG, "POST SYNC OT resp " + resp);
        JSONObject respuestaJSON = new JSONObject(resp);
        
        String resultJSON = respuestaJSON.getString("valido"); // estado es el nombre del campo en el JSON
        String resultToken = respuestaJSON.getString("vali_toke"); // estado es el nombre del campo en el JSON
        
        Log.i(TAG, "POST SYNC OT RESULTJSON " + resultJSON);
        if (resultJSON.equals("S")) {
          
          Log.i(TAG, "Valido Ots ");
          
          JSONArray datosJSON = jsonTpotPendEnvi.getJSONArray("tpot"); // estado es el nombre del campo en el JSON
          /// SE GENERA UN ARRAY DE LOS DATOS QUE YA HEMOS GENERO
          
          Log.i(TAG, "Json Ots " + datosJSON.toString());
          for (int i = 0; i < datosJSON.length(); i++) {
            TrasOt tpotUpdEnvi = new TrasOt(); /// CREA UN OBJETO PARA CADA UNA DE ESA OT Y LE HACE EL UPDATE
            
            tpotUpdEnvi.setTpotNroOt(Integer.valueOf(datosJSON.getJSONObject(i).getString("TPOT_NRO_OT")));
            tpotUpdEnvi.setTpotDeposito(datosJSON.getJSONObject(i).getInt("TPOT_DEPOSITO"));
            tpotUpdEnvi.setTpotArticulo(datosJSON.getJSONObject(i).getInt("TPOT_ARTICULO"));
            tpotUpdEnvi.setTpotCantidad(datosJSON.getJSONObject(i).getInt("TPOT_CANTIDAD"));
            tpotUpdEnvi.setTpotLote1(datosJSON.getJSONObject(i).getString("TPOT_LOTE1"));
            tpotUpdEnvi.setTpotCantidad1(datosJSON.getJSONObject(i).getInt("TPOT_CANTIDAD1"));
            tpotUpdEnvi.setTpotLote2(datosJSON.getJSONObject(i).getString("TPOT_LOTE2"));
            tpotUpdEnvi.setTpotCantidad2(datosJSON.getJSONObject(i).getInt("TPOT_CANTIDAD2"));
            tpotUpdEnvi.setTpotSolicitud(datosJSON.getJSONObject(i).getString("TPOT_SOLICITUD"));
            tpotUpdEnvi.setTpotPreparadoPor(datosJSON.getJSONObject(i).getInt("TPOT_PREPARADO_POR"));
            tpotUpdEnvi.setTpotClaveEntregaPrd(datosJSON.getJSONObject(i).getInt("TPOT_CLAVE_ENTREGA_PRD"));
            tpotUpdEnvi.setTpotEstado(datosJSON.getJSONObject(i).getString("TPOT_ESTADO"));
            
           /* String tpotDetaMate = datosJSON.getJSONObject(i).optString("ORTR_DETA_MATE");
            
            if (!tpotDetaMate.equals("")) {
              tpotUpdEnvi.setTpotIndiEdit(datosJSON.getJSONObject(i).getString("ORTR_DETA_MATE"));
            }
            
            //String tpotFechLiqui = datosJSON.getJSONObject(i).optString("ORTR_FECH_LIQU");
            
            if (!tpotFechLiqui.equals("")) {
              tpotUpdEnvi.setTpotFechLiqu(datosJSON.getJSONObject(i).getString("ORTR_FECH_LIQU"));
            }
            
            tpotUpdEnvi.setTpotVehiCodi(datosJSON.getJSONObject(i).getString("ORTR_VEHI_CODI"));
            tpotUpdEnvi.setTpotVehiIden(datosJSON.getJSONObject(i).getString("ORTR_VEHI_IDEN"));
            tpotUpdEnvi.setTpotNumePate(datosJSON.getJSONObject(i).getString("ORTR_NUME_PATE"));
            tpotUpdEnvi.setTpotLugaInst(datosJSON.getJSONObject(i).getString("ORTR_LUGA_INST"));
            tpotUpdEnvi.setTpotServObse(datosJSON.getJSONObject(i).getString("ORTR_SERV_OBSE"));
            */
            db.updateTpot(tpotUpdEnvi); /// ACA ACTUALIZA LISTA
            
            ActualizarLista(); /// VUELVE A REFRESCAR LA PANTALLA
            
          }
          
          Parametros.showToast("Datos enviados con éxito. ", py.com.unionsrl.labot.EntmListActivity.this);
          
        } else if (resultJSON.equals("-1")) { // SI HAY ERROR ENTRA ACA
          AlertDialog alertDialog = new AlertDialog.Builder(py.com.unionsrl.labot.EntmListActivity.this).create();
          
          // Setting Dialog Title
          alertDialog.setTitle("Atención");
          
          // Setting Dialog Message
          alertDialog.setMessage("Tiempo de espera agotado.");
          
          // Setting Icon to Dialog
          //alertDialog.setIcon(R.drawable.ic_launcher_background);
          
          // Showing Alert Message
          alertDialog.show();
        } else { /// ERROR EN EL FALLO EN LA AUNTENTICACION
          //Toast.makeText(view.getContext(),"@string/msgErrorAut", Toast.LENGTH_SHORT).show();
          
          AlertDialog alertDialog = new AlertDialog.Builder(py.com.unionsrl.labot.EntmListActivity.this).create();
          
          // Setting Dialog Title
          alertDialog.setTitle("Atención");
          
          // Setting Dialog Message
          if (resultToken.equalsIgnoreCase("N")) {
            alertDialog.setMessage("Error de autenticación, token inválido.");
          } else {
            alertDialog.setMessage("Error en el proceso de actualización");
          }
          // Setting Icon to Dialog
          //alertDialog.setIcon(R.drawable.ic_launcher_background);
          
          // Showing Alert Message
          alertDialog.show();
        }
        // Close the progressdialog
        
      } catch (JSONException e) {
        AlertDialog alertDialog = new AlertDialog.Builder(py.com.unionsrl.labot.EntmListActivity.this).create();
        alertDialog.setTitle("Atención");
        alertDialog.setMessage("Conexión Inválida");
        alertDialog.show();
        
        e.printStackTrace();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
  
}