package py.com.unionsrl.labot;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class httpHandler {
    private static final String TAG = "httpHandler";
    private static final String USER_AGENT = "Mozilla/5.0";
    
    public String getLogin(String GET_URL) throws JSONException {
        String resp = "";
        try {
            URL obj = new URL(GET_URL);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setConnectTimeout(60000);
            Log.i(TAG, "222222222");
            int responseCode = con.getResponseCode();
            Log.i(TAG, "333333333");
            Log.d("Handler", "GET Response Code :: " + responseCode);
            Log.i(TAG, "44444444444");
            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                resp = response.toString();
                // print result
                Log.d("Handler", response.toString());
            } else {
                resp = "" + responseCode;
                Log.d("Handler", "GET request not worked " +resp);
            }
        } catch (java.net.SocketTimeoutException e) {
            JSONObject jsonObj = new JSONObject("{\"cuenta\":\"-1\"}");
            return jsonObj.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString() + "";
            //return "error";
        }
        return resp;
    }
    
    public String getOrdeTrab(String GET_URL) throws JSONException {
        String resp = "";
        try {
            URL obj = new URL(GET_URL);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setConnectTimeout(60000);
            
            int responseCode = con.getResponseCode();
            Log.d(TAG, "GET Response Code :: " + responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                InputStream inS = new BufferedInputStream(con.getInputStream());
                
                BufferedReader in = new BufferedReader(new InputStreamReader(inS,"UTF-8"));
                String inputLine;
                StringBuffer response = new StringBuffer();
                
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                resp = response.toString();
                // print result
                Log.d(TAG, response.toString());
            } else {
                resp = "" + responseCode;
                Log.d(TAG, "GET request not worked "+resp);
            }
        } catch (java.net.SocketTimeoutException e) {
            JSONObject jsonObj = new JSONObject("{\"valido\":\"-1\"}");
            return jsonObj.toString();
        } catch (Exception e) {
            e.printStackTrace();
            JSONObject jsonObj = new JSONObject("{\"valido\":\"-2\"}");
            return jsonObj.toString();
            //return "error";
        }
        return resp;
    }
    
    public static String getJSON(String url, String json, int timeout, String method) throws JSONException{
        String resp = "";
        HttpURLConnection connection = null;
        try {
            
            URL u = new URL(url);
            connection = (HttpURLConnection) u.openConnection();
            connection.setRequestMethod(method);
            
            //set the sending type and receiving type to json
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("USER_TOKE", Parametros.userToken);
            
            connection.setAllowUserInteraction(false);
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(timeout);
            
            Log.i(TAG, "user token : " + Parametros.userToken);
            Log.i(TAG, "HTTP JSON : " + json);
            
            if (json != null) {
                //set the content length of the body
                connection.setRequestProperty("Content-length", json.getBytes().length + "");
                connection.setDoInput(true);
                connection.setDoOutput(true);
                connection.setUseCaches(false);
                
                //send the json as body of the request
                OutputStream outputStream = connection.getOutputStream();
                outputStream.write(json.getBytes("UTF-8"));
                outputStream.close();
            }
            
            //Connect to the server
            connection.connect();
            
            int status = connection.getResponseCode();
            Log.i(TAG, "HTTP status code : " + status);
            if (status == HttpURLConnection.HTTP_OK) { // success
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                bufferedReader.close();
                Log.i(TAG, "Received String : " + sb.toString());
                //return received string
                resp = sb.toString();
            } else {
                resp = "" + status;
                Log.d("Handler", "GET request not worked "+resp);
            }
            
        } catch (MalformedURLException ex) {
            Log.e(TAG, "Error in http connection1" + ex.toString());
            JSONObject jsonObj = new JSONObject("{\"valido\":\"-1\"}");
            return jsonObj.toString();
        } catch (IOException ex) {
            Log.e(TAG, "Error in http connection2" + ex.toString());
            JSONObject jsonObj = new JSONObject("{\"valido\":\"-1\"}");
            return jsonObj.toString();
        } catch (Exception ex) {
            Log.e(TAG, "Error in http connection3" + ex.toString());
            JSONObject jsonObj = new JSONObject("{\"valido\":\"-1\"}");
            return jsonObj.toString();
        } finally {
            if (connection != null) {
                try {
                    connection.disconnect();
                } catch (Exception ex) {
                    Log.e(TAG, "Error in http connection4" + ex.toString());
                    JSONObject jsonObj = new JSONObject("{\"valido\":\"-1\"}");
                    return jsonObj.toString();
                }
            }
        }
        
        return resp;
        
    }
}