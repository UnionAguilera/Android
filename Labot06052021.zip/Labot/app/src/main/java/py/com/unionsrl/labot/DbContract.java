package py.com.unionsrl.labot;

import android.provider.BaseColumns;

import java.util.Date;

public class DbContract {
  
  public interface Tables {
    
    String LOGIN = "LOGIN";
    String CONFIG = "CONFIG";
    String ORDE_TRAB = "COME_ORDE_TRAB";
    String TRAS_OT = "LABO_TRASLADOS_OT";
    
  }
  
  interface LoginColumns {
    
    String userlogin = "USER_lOGIN";
    String userName = "USER_NAME";
    String userToken = "USER_TOKE";
    String userEmplCodi = "USER_EMPL_CODI";
    String userDepoCodi = "USER_DEPO_CODI";
  }
  
  interface ConfigColumns {
    
    String confProtocol = "CONF_PROT";
    String confHost = "CONF_HOST";
    String confPort = "CONF_PORT";
  }
  
  interface TrasOtColumns {
    String tpotNroOt =           "TPOT_NRO_OT";
    String tpotSolicitud =       "TPOT_SOLICITUD";
    String tpotFecha =           "TPOT_FECHA";
    String tpotDeposito =        "TPOT_DEPOSITO";
    String tpotDescDeposito =    "TPOT_DESC_DEPOSITO";
    String tpotArticulo =        "TPOT_ARTICULO";
    String tpotAlfanumerico =    "TPOT_ALFANUMERICO";
    String tpotDescArticulo =    "TPOT_DESC_ARTICULO";

    String tpotCantidad =        "TPOT_CANTIDAD";
    String tpotLote1 =           "TPOT_LOTE1";
    String tpotCantidad1 =       "TPOT_CANTIDAD1";
    String tpotLote2 =           "TPOT_LOTE2";
    String tpotCantidad2 =       "TPOT_CANTIDAD2";

    String tpotPreparadoPor =    "TPOT_PREPARADO_POR";
    String tpotClaveEntregaPrd = "TPOT_CLAVE_ENTREGA_PRD";
    String tpotEstado =          "TPOT_ESTADO";
    String tpotIndEnvio=         "TPOT_IND_ENVIO";
  }
  
  // LOGIN
  public static class Login implements LoginColumns, BaseColumns {
    
  }
  
  public static class Config implements ConfigColumns, BaseColumns {
    
  }
  
}