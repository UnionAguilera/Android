package py.com.unionsrl.labot;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  private static String TAG = "MainActivity";
  private Database db = new Database(this);
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    
    Login login;
    
    login = db.selectLogin();
    
    Log.d(TAG, "Login token " + login.getUserToken());
    
    
    Config config;
    config = db.selectConfig();
    
    if (config.getConfHost() == null) {
      iniciarConfig();
    } else {
      if (login.getUserToken() == null) {
        
        //iniciarLogin();
        iniciarMenu();
      } else {
        Parametros.userLogin = login.getUserLogin();
        Parametros.userName = login.getUserName();
        Parametros.userToken = login.getUserToken();
        Parametros.userEmplCodi = login.getUserEmplCodi();
        Parametros.userDepoCodi = login.getUserDepoCodi();
        Parametros.confProtocol = config.getConfProtocol();
        Parametros.confHost = config.getConfHost();
        Parametros.confPort = config.getConfPort();
        iniciarMenu();
      }
    }
    
  }
  
  private void iniciarLogin() {
    
    Intent i = new Intent(this, LoginActivity.class);
    
    startActivity(i);
    
    finish();
    
  }
  
  private void iniciarMenu() {
    
    Intent i = new Intent(this, MenuActivity.class);
    
    startActivity(i);
    
    finish();
    
  }
  
  public void iniciarConfig() {
    
    Intent i = new Intent(this, ConfigActivity.class);
    
    startActivity(i);
    
    finish();
    
  }
}