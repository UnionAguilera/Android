package py.com.unionsrl.labot;

public class Config {
    private String confProtocol;
    private String confHost;
    private String confPort;

    public String getConfProtocol() {
        return confProtocol;
    }

    public void setConfProtocol(String confProtocol) {
        this.confProtocol = confProtocol;
    }

    public String getConfHost() {
        return confHost;
    }

    public void setConfHost(String confHost) {
        this.confHost = confHost;
    }

    public String getConfPort() {
        return confPort;
    }

    public void setConfPort(String confPort) {
        this.confPort = confPort;
    }


}
