package py.com.unionsrl.labot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {
  private static String TAG = "MenuActivity";
  private TextView txtMenuUsuario;
  private Button btnMenuTpot;
  private Button btnMenuSync;
  private Button btnCerrarSesion;
  private Database db = new Database(this);
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_menu);
    
    txtMenuUsuario = (TextView) findViewById(R.id.txtMenuUsuario);
    btnMenuTpot = (Button) findViewById(R.id.btnMenuTpot);
    btnMenuSync = (Button) findViewById(R.id.btnMenuSync);
    btnCerrarSesion = (Button) findViewById(R.id.btnCerrarSesion);
    
    txtMenuUsuario.setText("Bienvenido " + Parametros.userName);
    setupBtnMenuTpot();
    setupBtnMenuSync();
    setupBtnCerrarSesion();
    
    
  }
  
  private void setupBtnMenuTpot() {
    btnMenuTpot.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent i = new Intent(v.getContext(), EntmListActivity.class);
        
        startActivity(i);
        
      }
    });
  }
  
  private void setupBtnMenuSync() {
    btnMenuSync.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent i = new Intent(v.getContext(), py.com.unionsrl.labot.SyncActivity.class);
        
        startActivity(i);
        
      }
    });
  }
  
  private void setupBtnCerrarSesion() {
    btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        
        db.deleteLogin();
        
        iniciarLogin();
      }
    });
  }
  
  private void iniciarLogin() {
    Intent i = new Intent(this, LoginActivity.class);
    
    startActivity(i);
    
    finish();
  }
}