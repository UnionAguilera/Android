package py.com.unionsrl.labot;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EntmEditActivity extends AppCompatActivity {
  private static final String TAG = "EntmEditActivity";
  private Database db = new Database(this);
  private TrasOt tpot;
  
  private TextView txtEditTpotNroOt;
  private TextView txtEditTpotSolicitud;
  private TextView txtEditTpotArticulo;
  private TextView txtEditTpotCantidad;
  private EditText etEditTpotLote1;
  private EditText etEditTpotCantidad1;
  private EditText etEditTpotLote2;
  private EditText etEditTpotCantidad2;
  
  private TextView txtEditTpotPreparadoPor;
  private EditText etEditTpotClaveEntregaPrd;
  private TextView txtEditTpotDeposito;
  private TextView txtEditTpotEstado;
  private Button btnEditTpotLiquidar;
  //para recuperar los datos
  private String tpotNroOr;
  private String tpotArticulo;
  private Boolean Liquidado = false;
  private String mensaje;
  private String Cantidad1;
  private String Cantidad2;
  
  
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_entm_edit);
    
    txtEditTpotNroOt = (TextView) findViewById(R.id.txtEditTpotNroOt);
    txtEditTpotSolicitud = (TextView) findViewById(R.id.txtEditTpotSolicitud);
    txtEditTpotArticulo = (TextView) findViewById(R.id.txtEditTpotArticulo);
    txtEditTpotCantidad = (TextView) findViewById(R.id.txtEditTpotCantidad);
    etEditTpotLote1 = (EditText) findViewById(R.id.etEditTpotLote1);
    etEditTpotCantidad1 = (EditText) findViewById(R.id.etEditTpotCantidad1);
    etEditTpotLote2 = (EditText) findViewById(R.id.etEditTpotLote2);
    etEditTpotCantidad2 = (EditText) findViewById(R.id.etEditTpotCantidad2);
    txtEditTpotPreparadoPor = (TextView) findViewById(R.id.txtEditTpotPreparadoPor);
    etEditTpotClaveEntregaPrd = (EditText) findViewById(R.id.etEditTpotClaveEntregaPrd);
    txtEditTpotDeposito = (TextView) findViewById(R.id.txtEditTpotDeposito);
    txtEditTpotEstado = (TextView) findViewById(R.id.txtEditTpotEstado);
    btnEditTpotLiquidar = (Button) findViewById(R.id.btnEditTpotLiquidar);

/// recupera los datos enviados como parametro de artrlistactiviti lo que escucho del click
    Intent intent = getIntent();
    
    Bundle extras = intent.getExtras();
////recupera el codigo del parametro
    tpotNroOr = extras.getString("tpotNroOt");
    tpotArticulo = extras.getString("tpotArticulo");
/// la clase tpot setea y envia los valores
    
    tpot = db.selectTrasOtByCodi(tpotNroOr, tpotArticulo);
    /// PARA DESLIQUIDAR CONSULTA POR EL ESTADO  Y CARGA EN LA VARIABLE TRUE O FALSE EN LA VARIABLE LIQUIDADO
    if (tpot.getTpotEstado().equalsIgnoreCase("L")) {
      Liquidado = true;
    } else {
      Liquidado = false;
    }
    MostrarDatos(); //recupera los datos para los text view
    setupBtnEditTpotLiquidar();
    
  }
  
  public void MostrarDatos() {
    txtEditTpotNroOt.setText("Nro OT: " + tpot.getTpotNroOt().toString());
    txtEditTpotSolicitud.setText("Solicitud: " + tpot.getTpotSolicitud());
    txtEditTpotDeposito.setText("Depósito: " + tpot.getTpotDeposito().toString());
    if (tpot.getTpotSolicitud().equalsIgnoreCase("N")) {
      txtEditTpotSolicitud.setText("Tipo: Normal");
    } else {
      txtEditTpotSolicitud.setText("Tipo: Adicional");
    }
    txtEditTpotArticulo.setText("Artículo: " + tpot.getTpotAlfanumerico());
    if (tpot.getTpotEstado().equalsIgnoreCase("P")) {
      txtEditTpotEstado.setText("Estado: Pendiente");
      Liquidado = false;
    } else {
      txtEditTpotEstado.setText("Estado: Liquidado");
      Liquidado = true;
    }
    
    txtEditTpotCantidad.setText("Cantidad: " + tpot.getTpotCantidad().toString());
    etEditTpotLote1.setText(tpot.getTpotLote1());
    if(etEditTpotLote1.length()!=0){
      etEditTpotLote1.setText("Lote1: " + tpot.getTpotLote1());
      etEditTpotCantidad1.setText("Cantidad1: " + tpot.getTpotCantidad1().toString());
    }
    etEditTpotLote2.setText(tpot.getTpotLote2());
    if(etEditTpotLote2.length()!=0){
      etEditTpotLote2.setText("Lote2: " + tpot.getTpotLote2());
      etEditTpotCantidad2.setText("Cantidad2: " + tpot.getTpotCantidad2().toString());
    }


    txtEditTpotPreparadoPor.setText("Preparador Por: " + tpot.getTpotPreparadoPor().toString());
    //etEditTpotClaveEntregaPrd.setText(tpot.getTpotClaveEntregaPrd());
    
    if (Liquidado) {
      btnEditTpotLiquidar.setText("Desliquidar OT");
    } else {
      btnEditTpotLiquidar.setText("Liquidar OT");
    }
    
  }
  
  
  private void liquidarTpot() {
    try { /// se usa para saber si tiene o no error siempre hay que meter por aca los metodos de  insercion o update
      
      tpot.setTpotEstado("L"); /// envia a tpot en la base de datos y actualiza a L LIQUIDADO LA OT
      //tpot.setTpotIndiEdit("S"); /// ACA SE IDENTIFICA SI YA SE EDITO LA OT ASI AL SINCRONIZAR LAS OT NO SE BORREN O PISEN LOS CAMBIOS QUE SE HAN HECHO, PORQUE AL SINCRONIZAR SI O SI BORRAN Y VUELVEN A CARGAR
      Log.d(TAG, "Tpot Estado " + tpot.getTpotEstado());
      /*DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
      String fechLiqu = df.format(new Date());
      tpot.setTpotFechLiqu(fechLiqu);*/

      tpot.setTpotLote1(etEditTpotLote1.getText().toString());
      Cantidad1 = etEditTpotCantidad1.getText().toString();
      if(Cantidad1.length()!=0){
         tpot.setTpotCantidad1(Integer.valueOf(etEditTpotCantidad1.getText().toString()));
      }

      tpot.setTpotLote2(etEditTpotLote2.getText().toString());
      Cantidad2 = etEditTpotCantidad2.getText().toString();
      if(Cantidad2.length()!=0){
        tpot.setTpotCantidad2(Integer.valueOf(etEditTpotCantidad2.getText().toString()));
      }

      tpot.setTpotClaveEntregaPrd(Integer.valueOf(etEditTpotClaveEntregaPrd.getText().toString()));

      db.updateTpot(tpot);
      Liquidado = true; //ACA AL LIQUIDAR OT PASA A TRUE QUE ES LIQUIDADO Y ABAJO EL BOTON CAMBIA DE VALOR
      btnEditTpotLiquidar.setText("Desliquidar OT"); /// CAMBIA PARA DESLIQUIDAR OT
      MostrarDatos();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //////////////////// /// METODO QUE ESCUCHA EL LISTENER PARA LIQUIDAR OT
  private void setupBtnEditTpotLiquidar() {
    btnEditTpotLiquidar.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Log.d(TAG, " Liquidar " + tpot.getTpotEstado());
// ACA SE LE LLAMA A LIQUIDAR OT PRIMERO ESU¿CUCHA EL LISTENER  PARA SER PROCESADO EN ONCREATE y consulta por  la variable liquidado
        if (!Liquidado) {
          
          if (!validaCargaLugar()) { /// llama a validar carga de lugar
            
            etEditTpotClaveEntregaPrd.requestFocus();
            Parametros.showToast(mensaje, py.com.unionsrl.labot.EntmEditActivity.this);
            
          } else if (!validaCargaObse()) { //// llama al metodo validar observacion
            etEditTpotLote1.requestFocus();
            Parametros.showToast(mensaje, py.com.unionsrl.labot.EntmEditActivity.this);
          } else {
            liquidarTpot(); /// si no es liquidado llama a liquidar
            
            finish();
          }
        } else {
          desLiquidarTpot();  /// si no es liquidado llama a desliquidar
        }
        
      }
    });
    
    
  }
  
  
  ///// ACA DESLIQUIDA LA OT
  private void desLiquidarTpot() {
    tpot.setTpotEstado("P"); //VUELVE A ESTA PENDIENTE
    //tpot.setTpotIndiEdit("N");// PASA YA A SER NO EDITADO
    //tpot.setTpotFechLiqu(""); // Y NULA LA FECHA DE LIQUIDAACION

    tpot.setTpotLote1("");
    tpot.setTpotCantidad1(0);
    tpot.setTpotLote2("");
    tpot.setTpotCantidad2(0);
    tpot.setTpotPreparadoPor(0);
    tpot.setTpotClaveEntregaPrd(0);

    Log.d(TAG, "Tpot EstadoP " + tpot.getTpotEstado());
    db.updateTpot(tpot);
    //CAMBIA EL ESTADO A DESLIQUIDADO
    Liquidado = false;
    btnEditTpotLiquidar.setText("Liquidar OT");
    MostrarDatos();
  }

  // ACA LAS VALIDACIONES PARA LUGAR Y OBSERVACION
  private boolean validaCargaLugar() {
    boolean datosValidos = true;
    String s = "";
    s = etEditTpotClaveEntregaPrd.getText().toString().trim();
    if (s.length() == 0) {
      mensaje = "La carga del lugar es obligatoria. ";
      datosValidos = false;
    } else if (s.length() <= 3) {
      mensaje = "El lugar debe contener al menos 4 caracteres. ";
      datosValidos = false;
    }
    
    return datosValidos;
  }
  
  private boolean validaCargaObse() {
    boolean datosValidos = true;
    String s = "";
    s = etEditTpotClaveEntregaPrd.getText().toString().trim();
    if (s.length() == 0) {
      mensaje = "La carga de la observación es obligatoria. ";
      datosValidos = false;
    } else if (s.length() <= 3) {
      mensaje = "La observación debe contener al menos 4 caracteres. ";
      datosValidos = false;
    }
    
    return datosValidos;
  }
}


